from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Q
from . import team_maker

from django.db.models import Count

def index(request):
	context = {
		#
		#  SPORTS ORM II
		#
		# 1...all teams in the Atlantic Soccer Conference
		# "all_Atlantic":Team.objects.filter( league=League.objects.all().filter(name="Atlantic Soccer Conference")),
		"all_Atlantic":Team.objects.filter( league__name="Atlantic Soccer Conference"),
		# 2...all (current) players on the Boston Penguins
		"all_players_bp":Player.objects.filter(curr_team__team_name="Penguins"),
		# 3...all (current) players in the International Collegiate Baseball Conference
		"cplyrs_icbc":Player.objects.filter( curr_team__league__name="International Collegiate Baseball Conference"),
		# 4...all (current) players in the American Conference of Amateur Football with last name "Lopez"
		"fourth_ass":Player.objects.filter(last_name="Lopez").filter( curr_team__league__name="American Conference of Amateur Football"),
		# 5...all football players
		"fifth_ass":Player.objects.filter( curr_team__league__sport__iexact="football"),
		# 6...all teams with a (current) player named "Sophia"
		"sixth_ass":Team.objects.filter( curr_players__first_name="Sophia"),
		# 7....all leagues with a (current) player named "Sophia"
		"seventh_ass":League.objects.filter( teams__curr_players__first_name="Sophia"),
		# 8....everyone with the last name "Flores" who DOESN'T (currently) play for the Washington Roughriders
		"eight_ass":Player.objects.filter( last_name="Flores").exclude(curr_team__team_name="Washington Roughriders"),
		# 9....all teams, past and present, that Samuel Evans has played with
		"ninth_ass":Team.objects.filter( all_players__first_name="Samuel", all_players__last_name="Evans"),
		# 10. ...all players, past and present, with the Manitoba Tiger-Cats
		"tenth_ass":Player.objects.filter( all_teams__team_name="Tiger-Cats"),
		# 11. ...all players who were formerly (but aren't currently) with the Wichita Vikings
		"eleven_ass":Player.objects.filter( all_teams__team_name="Vikings").exclude(curr_team__team_name="Vikings"),
		# 12. ...every team that Jacob Gray played for before he joined the Oregon Colts
		"twlw_ass":Team.objects.filter( all_players__first_name="Jacob", all_players__last_name="Gray").exclude(curr_players__first_name="Jacob", curr_players__last_name="Gray"),
		# 13. ...everyone named "Joshua" who has ever played in the Atlantic Federation of Amateur Baseball Players
		"thrd_ass":Player.objects.filter( first_name="Joshua").filter( Q(all_teams__league__name__contains="Atlantic Federation") | Q(all_teams__league__name__contains="Amateur Baseball Players") ),
		# 14. ...all teams that have had 12 or more players, past and present. (HINT: Look up the Django annotate function.)
		#  leagues_player     leagues_league     leagues_team
		# "fth_ass":Team..objects.raw('SELECT * FROM myapp_person')
		#  [:10] - only first 10 records
		"fth_ass":Team.objects.annotate( our_param=Count("all_players")).filter(our_param__gt=12) ,
		# 15...all players, sorted by the number of teams they've played for
		"fifth_qry":Player.objects.annotate( our_param=Count("all_teams") ).order_by("-our_param") ,

		#
		#  SPORTS ORM
		#
		"bascetball": League.objects.filter(name__contains='baseball'),
		"womens": League.objects.filter(name__contains='womens'),
		"hockey": League.objects.filter(name__contains='hockey'),
		"notFootbal": League.objects.all().exclude(name__contains="football"),
		"conferences": League.objects.filter(name__contains='Conference'),
		"atlantic": League.objects.filter(name__contains='Atlantic'),

		"dallas": Team.objects.filter(location__contains='Dallas'),
		"raptors": Team.objects.filter(team_name__contains='Raptors'),
		"city": Team.objects.filter(location__contains='City'),
		"t_start": Team.objects.filter(team_name__startswith='T'),
		"asc": Team.objects.all().order_by('team_name'),
		"desc": Team.objects.all().order_by('-team_name'),

		#  case insensitive
		"cooper": Player.objects.filter(last_name__iexact='Cooper'),
		"joshua": Player.objects.filter(first_name__contains='Joshua'),

		"cooper_not_joshua": Player.objects.filter(last_name__contains='Cooper').exclude(first_name__contains="Joshua"),
		# Multiple OR query
		"alexander_or_whyatt": Player.objects.filter( Q(first_name__contains='Alexander') | Q(first_name__contains='Wyatt') ),

		# old queries
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
